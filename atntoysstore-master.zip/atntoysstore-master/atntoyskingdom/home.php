<!DOCTYPE html>
<!-- saved from url=(0064)https://www.w3schools.com/w3css/tryw3css_templates_architect.htm -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title></title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="image/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-wide w3-padding w3-card">
    <a href="index.php" class="w3-bar-item w3-button"><b>ATN</b> Toy Store</a>
    <!-- Float links to the right. Hide them on small screens -->
    <div class="w3-right w3-hide-small">
        <a href="home.php" class="w3-bar-item w3-button">Home</a>
        <a href="view.php" class="w3-bar-item w3-button">View</a>
        <a href="insert.php" class="w3-bar-item w3-button">Insert</a>
        <a href="update.php" class="w3-bar-item w3-button">Update</a>
        <a href="delete.php" class="w3-bar-item w3-button">Delete</a>
    </div>
  </div>
</div>

<!-- Header -->
<header class="w3-display-container w3-content w3-wide" style="max-width:1500px;" id="home">
  <img class="w3-image" src="image/architect.jpg" alt="Architecture" width="1500" height="800">
  <div class="w3-display-middle w3-margin-top w3-center">


<span class="w3-padding w3-black w3-opacity-min"><b>ATN</b></span><span class="w3-hide-small w3-text-light-grey">Toy Store</span>
		
		  <!-- Contact Section 
		  <div class="w3-container w3-padding-32" id="contact">
		    <h3 class="w3-border-bottom w3-border-light-grey w3-padding-16">Contact</h3>
		    <p>Lets get in touch and talk about your next project.</p>
		    <form action="https://www.w3schools.com/action_page.php" target="_blank">
		      <input class="w3-input w3-border" type="text" placeholder="Name" required="" name="Name">
		      <input class="w3-input w3-section w3-border" type="text" placeholder="Email" required="" name="Email">
		      <input class="w3-input w3-section w3-border" type="text" placeholder="Subject" required="" name="Subject">
		      <input class="w3-input w3-section w3-border" type="text" placeholder="Comment" required="" name="Comment">
		      <button class="w3-button w3-black w3-section" type="submit">
		        <i class="fa fa-paper-plane"></i> SEND MESSAGE
		      </button>
		    </form>
		  </div>
			-->

    
  </div>
</header>

<footer class="w3-center w3-black w3-padding-16">
  <p>Assignment 2 <a href="#" title="Submited" target="_blank" class="w3-hover-text-green">Cloud Computing</a></p>
</footer>


</body></html>